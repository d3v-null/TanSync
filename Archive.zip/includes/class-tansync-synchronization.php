<?php

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'TANSYNC_EGRESS', 0);
define( 'TANSYNC_INGRESS', 1);
define( 'TANSYNC_VIRGIN', 0);
define( 'TANSYNC_PENDING', 1);
define( 'TANSYNC_COMPLETE', 2);


/**
* Deals with the extra fields
*/
class Tansync_Synchronization{
    
    /**
     * The single instance of Tansync_Synchronization.
     * @var     object
     * @access  private
     * @since   1.0.0
     */
    private static $_instance = null;

    /**
     * Parent class object
     * @var     object
     * @access  public
     * @since   1.0.0
     */
    public $parent = null;

    /**
     * Settings class object
     * @var     object
     * @access  public
     * @since   1.0.0
     */
    public $settings = null;

    public $update_table_suffix = 'tansync_updates';

    private $tabledata = array(
        'columns' => array(
            'id'=>'mediumint(9) NOT NULL AUTO_INCREMENT',
            'user_id'=>'int NOT NULL',
            'direction' => 'int NOT NULL',
            'status' => 'int NOT NULL',
            'time' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL',
            'data' => 'text NOT NULL',
        ),
        'unique key' => 'UNIQUE KEY id (id)'
    );

    function __construct($parent)
    {
        $this->parent = $parent;
        $this->settings = $parent->settings;

        // do_action( 'profile_update', $userid, $old_userdata );
        add_action( 'profile_update', array(&$this, 'handle_profile_update') );
        // do_action( 'user_register', $userid );
        add_action( 'user_register', array(&$this, 'handle_user_register') );
    }

    public function install_tables(){
        error_log("calling Tansync_Synchronization -> install_tables");
        global $wpdb;
        $update_table_name = $wpdb->prefix . $this->update_table_suffix ;
        $charset_collate = $wpdb->get_charset_collate();


        // $sql = "CREATE TABLE IF NOT EXISTS $update_table_name (
        //         id mediumint(9) NOT NULL AUTO_INCREMENT,
        //         user_id int NOT NULL,
        //         time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
        //         data text NOT NULL,
        //         UNIQUE KEY id (id)
        //     ) $charset_collate;";

        // error_log("SQL 1: ".serialize($sql));

        $sql = "CREATE TABLE $update_table_name (";
        foreach ($this->tabledata['columns'] as $col => $params) {
            $sql .= $col . ' ' . $params . ', ';
        }
        $sql .= $this->tabledata['unique key'];
        $sql .= ") $charset_collate;";

        error_log("SQL 2: ".serialize($sql));

        $wpdb->query($sql);
    }

    public function uninstall_tables(){
        error_log("calling Tansync_Synchronization -> uninstall_tables");
        global $wpdb;
        $update_table_name = $wpdb->prefix . $this->update_table_suffix ;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "DROP TABLE $update_table_name;";

        $wpdb->query($sql); 
    }

    public function validate_install(){
        error_log("calling Tansync_Synchronization -> validate_install");
        global $wpdb;
        $update_table_name = $wpdb->prefix . $this->update_table_suffix ;
        $sql = $wpdb->prepare("SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = %s",$update_table_name);
        $table = $wpdb->get_row($sql, ARRAY_A);
        // error_log("table: ".serialize($table));
        if(!is_array($table) or empty($table)){
            //table does not exist, create it
            $this->install_tables();
        } else{
            // TODO: IF TABLE IS INVALID
            $sql = $wpdb->prepare("SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = %s",$update_table_name);
            $columns = $wpdb->get_results($sql, ARRAY_A);
            // error_log("columns: ".serialize($columns));
            foreach ($this->tabledata['columns'] as $colname => $params) {
                // error_log("looking for ".serialize($colname));
                $column_present = false;
                foreach ($columns as $column) {
                    // error_log("column: ".serialize($column));
                    if (isset($column['COLUMN_NAME'])){
                        if( $column['COLUMN_NAME'] == $colname){
                            $column_present = true;
                        }
                    }
                }
                if(!$column_present){
                    error_log("problem with tansync database, reinstalling");
                    $this->uninstall_tables();
                    $this->install_tables();
                    break;
                }
            }
        }

    }

    // public function get_ingress_updates(){
    //     //TODO: 
    //     // SELECT * FROM 
    //     // global $wpdb
    //     // $sql = $wpdb->prepare( 'SELECT sync_id, ')
    //     // $results = wpdb->get_results( 'SELECT * FROM ')
    // }

    // public function get_egress_updates(){
    //     //TODO: 
    // }


    public function handle_profile_update($userid, $old_userdata=null){
        error_log("USER PROFILE UPDATE".serialize($userid));

        //TODO: only generate changed user data

        $this->queue_update($userid);
    }

    public function handle_user_register($userid){
        error_log("USER REGISTRATION: ".serialize($userid));
        $this->queue_update($userid);
    }

    public function get_synced_fields(){
        $sync_settings_json = $this->settings->get_option("sync_field_settings");
        $sync_settings = json_decode($sync_settings_json);
        $synced_fields = array();
        if($sync_settings){
            foreach (get_object_vars($sync_settings) as $key => $value) {
                if( isset($value->sync_egress) and $value->sync_egress ){
                    $label = $key;
                    if(isset($value->label)) {$label = $value->label; }
                    if(isset($value->sync_label)) {$label = $value->sync_label;}
                    $synced_fields[$key] = $label;
                }
            }
        } else {
            error_log("TANSYNC: sync settings configured incorrectly");
        }

        return $synced_fields;
    }

    public function queue_update($userid, $userdata = null){
        error_log("TRIGGER SYNC: ".serialize($userid));
        // checks for pending ingress updates

        if(!$userdata){
            $userdata = get_object_vars(get_userdata( $userid )) + get_user_meta( $userid );
        }

        if ( $userdata instanceof stdClass ) {
            $userdata = get_object_vars( $userdata );
        } elseif ( $userdata instanceof WP_User ) {
            $userdata = $userdata->to_array();
        }

        // filter only sync'd fields
        $syncdata = array();
        $syncfields = $this->get_synced_fields();
        foreach ($syncfields as $key => $label) {
            if (isset($userdata[$key])){
                $syncdata[$label] = $userdata[$key];
            }
        }

        $userstring = json_encode($syncdata);

        global $wpdb;
        $update_table_name = $wpdb->prefix . $this->update_table_suffix ;

        $wpdb->insert(
            $update_table_name, 
            array( 
                'user_id' => $userid,
                'direction' => TANSYNC_EGRESS,
                'status' => TANSYNC_VIRGIN,
                'data' => $userstring
            ),
            array(
                'user_id' => '%d',
                'direction' => '%d',
                'status' => '%d',
                'data' => '%s'
            )
        );
    }

    // public function process_pending_egress(){

    // }

    // public function process_pending_ingress(){
    //     // load pending ingress from file

    //     foreach( $pending_ingress as $userdata ){

    //     }
    // }

    public function user_update($userid, $data){
        update_user_meta($userid, 'last_update', time());
    }

    /**
     * Main Tansync_Synchronization Instance
     *
     * Ensures only one instance of Tansync_Synchronization is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @see TanSync()
     * @return Main Tansync_Synchronization instance
     */
    public static function instance ( $parent ) {
        return new self( $parent );
        // if ( is_null( self::$_instance ) ) {
        //     self::$_instance = new self( $parent );
        // }
        // return self::$_instance;
    } // End instance()

}